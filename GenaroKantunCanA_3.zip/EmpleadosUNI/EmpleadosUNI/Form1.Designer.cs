﻿using System;

namespace EmpleadosUNI
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabpageEmpleado = new System.Windows.Forms.TabPage();
            this.dgvEmpleado = new System.Windows.Forms.DataGridView();
            this.tabPageCentroTrabajo = new System.Windows.Forms.TabPage();
            this.dgvCentroTrabajo = new System.Windows.Forms.DataGridView();
            this.tabPagePuesto = new System.Windows.Forms.TabPage();
            this.dgvPuesto = new System.Windows.Forms.DataGridView();
            this.tabPageDirectivo = new System.Windows.Forms.TabPage();
            this.dgvDirectivo = new System.Windows.Forms.DataGridView();
            this.tabControl1.SuspendLayout();
            this.tabpageEmpleado.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEmpleado)).BeginInit();
            this.tabPageCentroTrabajo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCentroTrabajo)).BeginInit();
            this.tabPagePuesto.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPuesto)).BeginInit();
            this.tabPageDirectivo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDirectivo)).BeginInit();
            this.SuspendLayout();

            this.tabControl1.Controls.Add(this.tabpageEmpleado);
            this.tabControl1.Controls.Add(this.tabPageCentroTrabajo);
            this.tabControl1.Controls.Add(this.tabPagePuesto);
            this.tabControl1.Controls.Add(this.tabPageDirectivo);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "TabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1024, 600);
            this.tabControl1.TabIndex = 0;

            this.tabpageEmpleado.Controls.Add(this.dgvEmpleado);
            this.tabpageEmpleado.Location = new System.Drawing.Point(4, 25);
            this.tabpageEmpleado.Name = "TabpageEmpleado";
            this.tabpageEmpleado.Padding = new System.Windows.Forms.Padding(3);
            this.tabpageEmpleado.Size = new System.Drawing.Size(1016, 571);
            this.tabpageEmpleado.TabIndex = 0;
            this.tabpageEmpleado.Text = "Empleado";
            this.tabpageEmpleado.UseVisualStyleBackColor = true;

            this.dgvEmpleado.AllowUserToAddRows = false;
            this.dgvEmpleado.AllowUserToDeleteRows = false;
            this.dgvEmpleado.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvEmpleado.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvEmpleado.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvEmpleado.Location = new System.Drawing.Point(3, 3);
            this.dgvEmpleado.Name = "dgvEmpleado";
            this.dgvEmpleado.ReadOnly = true;
            this.dgvEmpleado.RowHeadersWidth = 51;
            this.dgvEmpleado.RowTemplate.Height = 24;
            this.dgvEmpleado.Size = new System.Drawing.Size(1010, 565);
            this.dgvEmpleado.TabIndex = 0;

            this.tabPageCentroTrabajo.Controls.Add(this.dgvCentroTrabajo);
            this.tabPageCentroTrabajo.Location = new System.Drawing.Point(4, 25);
            this.tabPageCentroTrabajo.Name = "TabPageCentroTrabajo";
            this.tabPageCentroTrabajo.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageCentroTrabajo.Size = new System.Drawing.Size(1016, 571);
            this.tabPageCentroTrabajo.TabIndex = 1;
            this.tabPageCentroTrabajo.Text = "Centro de Trabajo";
            this.tabPageCentroTrabajo.UseVisualStyleBackColor = true;

            this.dgvCentroTrabajo.AllowUserToAddRows = false;
            this.dgvCentroTrabajo.AllowUserToDeleteRows = false;
            this.dgvCentroTrabajo.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvCentroTrabajo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCentroTrabajo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvCentroTrabajo.Location = new System.Drawing.Point(3, 3);
            this.dgvCentroTrabajo.Name = "dgvCentroTrabajo";
            this.dgvCentroTrabajo.ReadOnly = true;
            this.dgvCentroTrabajo.RowHeadersWidth = 51;
            this.dgvCentroTrabajo.RowTemplate.Height = 24;
            this.dgvCentroTrabajo.Size = new System.Drawing.Size(1010, 565);
            this.dgvCentroTrabajo.TabIndex = 0;

            this.tabPagePuesto.Controls.Add(this.dgvPuesto);
            this.tabPagePuesto.Location = new System.Drawing.Point(4, 25);
            this.tabPagePuesto.Name = "TabPagePuesto";
            this.tabPagePuesto.Padding = new System.Windows.Forms.Padding(3);
            this.tabPagePuesto.Size = new System.Drawing.Size(1016, 571);
            this.tabPagePuesto.TabIndex = 2;
            this.tabPagePuesto.Text = "Puesto";
            this.tabPagePuesto.UseVisualStyleBackColor = true;

            this.dgvPuesto.AllowUserToAddRows = false;
            this.dgvPuesto.AllowUserToDeleteRows = false;
            this.dgvPuesto.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvPuesto.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPuesto.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvPuesto.Location = new System.Drawing.Point(3, 3);
            this.dgvPuesto.Name = "dgvPuesto";
            this.dgvPuesto.ReadOnly = true;
            this.dgvPuesto.RowHeadersWidth = 51;
            this.dgvPuesto.RowTemplate.Height = 24;
            this.dgvPuesto.Size = new System.Drawing.Size(1010, 565);
            this.dgvPuesto.TabIndex = 0;

            this.tabPageDirectivo.Controls.Add(this.dgvPuesto);
            this.tabPageDirectivo.Location = new System.Drawing.Point(4, 25);
            this.tabPageDirectivo.Name = "TabPageDirectivo";
            this.tabPageDirectivo.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageDirectivo.Size = new System.Drawing.Size(1016, 571);
            this.tabPageDirectivo.TabIndex = 3;
            this.tabPageDirectivo.Text = "Directivo";
            this.tabPageDirectivo.UseVisualStyleBackColor = true;

            this.dgvDirectivo.AllowUserToAddRows = false;
            this.dgvDirectivo.AllowUserToDeleteRows = false;
            this.dgvDirectivo.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvDirectivo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDirectivo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvDirectivo.Location = new System.Drawing.Point(3, 3);
            this.dgvDirectivo.Name = "dgvDirectivo";
            this.dgvDirectivo.ReadOnly = true;
            this.dgvDirectivo.RowHeadersWidth = 51;
            this.dgvDirectivo.RowTemplate.Height = 24;
            this.dgvDirectivo.Size = new System.Drawing.Size(1010, 565);
            this.dgvDirectivo.TabIndex = 0;

            this.AutoScaleDimensions = new System.Drawing.SizeF(8f, 16f);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1024, 600);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Control de Empleados UNI";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabpageEmpleado.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvEmpleado)).EndInit();
            this.tabPageCentroTrabajo.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvCentroTrabajo)).EndInit();
            this.tabPagePuesto.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvPuesto)).EndInit();
            this.tabPageDirectivo.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDirectivo)).EndInit();
            this.ResumeLayout(false);
            this.Load += new System.EventHandler(this.Form1_Load);

        }

       
        
        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.dataGridView4 = new System.Windows.Forms.DataGridView();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1755, 748);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.dataGridView1);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1747, 719);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "tabPage1";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.dataGridView2);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1747, 719);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "tabPage2";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.dataGridView3);
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(1747, 719);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "tabPage3";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.dataGridView4);
            this.tabPage4.Location = new System.Drawing.Point(4, 25);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(1747, 719);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "tabPage4";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(3, 3);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.Size = new System.Drawing.Size(1741, 713);
            this.dataGridView1.TabIndex = 0;
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView2.Location = new System.Drawing.Point(3, 3);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowHeadersWidth = 51;
            this.dataGridView2.Size = new System.Drawing.Size(1741, 713);
            this.dataGridView2.TabIndex = 0;
            // 
            // dataGridView3
            // 
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView3.Location = new System.Drawing.Point(3, 3);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.RowHeadersWidth = 51;
            this.dataGridView3.Size = new System.Drawing.Size(1741, 713);
            this.dataGridView3.TabIndex = 0;
            // 
            // dataGridView4
            // 
            this.dataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView4.Location = new System.Drawing.Point(3, 3);
            this.dataGridView4.Name = "dataGridView4";
            this.dataGridView4.RowHeadersWidth = 51;
            this.dataGridView4.Size = new System.Drawing.Size(1741, 713);
            this.dataGridView4.TabIndex = 0;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1791, 765);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.tabPage4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabpageEmpleado;
        private System.Windows.Forms.DataGridView dgvEmpleado;
        private System.Windows.Forms.TabPage tabPageCentroTrabajo;
        private System.Windows.Forms.DataGridView dgvCentroTrabajo;
        private System.Windows.Forms.TabPage tabPagePuesto;
        private System.Windows.Forms.DataGridView dgvPuesto;
        private System.Windows.Forms.TabPage tabPageDirectivo;
        private System.Windows.Forms.DataGridView dgvDirectivo;
    }
}

