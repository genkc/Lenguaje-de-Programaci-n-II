﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace EmpleadosUNI
{
    public partial class Form1 : Form
    {
        private Empleados_UNIDataSet datos;

        private Empleados_UNIDataSetTableAdapters.EmpleadoTableAdapter EmpleadoTA;
        private Empleados_UNIDataSetTableAdapters.CentroTrabajoTableAdapter CentroTrabajoTA;
        private Empleados_UNIDataSetTableAdapters.PuestoTableAdapter PuestoTA;
        private Empleados_UNIDataSetTableAdapters.DirectivoTableAdapter DirectivoTA;
        public Form1()
        {

                InitializeComponent();
                datos = new Empleados_UNIDataSet();
                EmpleadoTA = new Empleados_UNIDataSetTableAdapters.EmpleadoTableAdapter();
                CentroTrabajoTA = new Empleados_UNIDataSetTableAdapters.CentroTrabajoTableAdapter();
                PuestoTA = new Empleados_UNIDataSetTableAdapters.PuestoTableAdapter();
                DirectivoTA = new Empleados_UNIDataSetTableAdapters.DirectivoTableAdapter();
       
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        private void Form1_Load(object sender, EventArgs e)
        { 
            try
            {
                EmpleadoTA.Fill(datos.Empleado);
                CentroTrabajoTA.Fill(datos.CentroTrabajo);
                PuestoTA.Fill(datos.Puesto);
                DirectivoTA.Fill(datos.Directivo);

                dgvEmpleado.DataSource = datos.Empleado;
                dgvCentroTrabajo.DataSource = datos.CentroTrabajo;
                dgvPuesto.DataSource = datos.Puesto;
                dgvDirectivo.DataSource = datos.Directivo;
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Error al cargar los datos desde la base de datos:\n" + ex.Message,
                    "Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }
        }
    }
}