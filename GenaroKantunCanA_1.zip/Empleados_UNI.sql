--Programa que permite a la empresa UNI llevar el contro de sus empleados
--Autor: Genaro Kantun Can
--Fecha: 24-11-2025
CREATE DATABASE Empleados_UNI

USE Empleados_UNI
-- Tabla CentroTrabajo
CREATE TABLE CentroTrabajo (
    Numero_Centro INT PRIMARY KEY,
    Nombre_Centro VARCHAR(100) NOT NULL,
    Ciudad varchar(100)
);
GO
-- Tabla Puesto
CREATE TABLE Puesto (
    Id_Puesto INT PRIMARY KEY IDENTITY(1,1),
    Nombre_Puesto VARCHAR(50) NOT NULL,
    Descripcion_Puesto VARCHAR(100)
);
GO
-- Tabla Empleado
CREATE TABLE Empleado (
    Numero_Empleado INT PRIMARY KEY IDENTITY(1,1),
    Nombre VARCHAR(50) NOT NULL,
    Apellido_Paterno VARCHAR(50) NOT NULL,
    Apellido_Materno VARCHAR(50) NOT NULL,
    Fecha_Nacimiento DATE NOT NULL,
    RFC VARCHAR(20) NOT NULL,
    Numero_Centro INT NOT NULL,
    Id_Puesto INT NOT NULL,
    Descripcion_Puesto VARCHAR(100),
    Directivo BIT NOT NULL,
    CONSTRAINT FK_Empleado_Centro FOREIGN KEY (Numero_Centro) REFERENCES CentroTrabajo(Numero_Centro),
    CONSTRAINT FK_Empleado_Puesto FOREIGN KEY (Id_Puesto) REFERENCES Puesto(Id_Puesto)
);
GO
-- Tabla Directivo
CREATE TABLE Directivo (
    Numero_Empleado INT PRIMARY KEY,
    Centro_Responsable INT NOT NULL,
    Prestacion_Combustible BIT NOT NULL,
    CONSTRAINT FK_Directivo_Empleado FOREIGN KEY (Numero_Empleado) REFERENCES Empleado(Numero_Empleado),
    CONSTRAINT FK_Directivo_Centro FOREIGN KEY (Centro_Responsable) REFERENCES CentroTrabajo(Numero_Centro)
);
GO
--Centros de trabajo
INSERT INTO CentroTrabajo (Numero_Centro, Nombre_Centro, Ciudad) VALUES
('1139', 'Tiendas Los Manguitos Muebles', 'Champot�n'),
('1037', 'Tiendas Justo Sierra Ropa', 'Esc�rcega'),
('7883', 'Tiendas Motos', 'Champot�n'),
('1051', 'Tiendas La Ceiba Muebles', 'Calkin�'),
('877', 'Tiendas Zapater�a Canada', 'Campeche'),
('1019', 'Tiendas San Rafael Muebles', 'Campeche');
GO
 --Puestos
INSERT INTO Puesto (Nombre_Puesto, Descripcion_Puesto) VALUES
('Vendedor', 'Vendedor de piso'),
('Cajera','Cajera Telefon�a'),
('Gerente', 'Gerente del centro Muebles'),
('Garant�as', 'Encargado de garant�as'),
('Gerente', 'Gerente del centro Ropa'),
('Cajero', 'Cajero Ropa'),
('Gerente', 'Gerente de Tienda Motos'),
('Auxiliar', 'Intendente'),
('Optometrista', 'Encargado Optica'),
('Inventarios', 'Inventarista de la zapater�a'),
('Gerente', 'Gerente de la Zapater�a'),
('Promotor', 'Promotor de clientes nuevos'),
('T�cnico', 'T�cnico de sector');
GO
--Empleados
INSERT INTO Empleado (Nombre, Apellido_Paterno, Apellido_Materno, Fecha_Nacimiento, RFC, Numero_Centro, Id_Puesto, Descripcion_puesto, Directivo) VALUES
('Genaro','Kantun','Can', '1988-06-15', 'KACG880615XXX','1139', 1,'Vendedor de piso', 0),
('Norma', 'Delgado', 'Garc�a', '1989-10-27', 'GADN871027XXX','1139', 2,'Cajera Telefon�a', 0),
('Hedit', 'Campos', 'Tuz', '1990-04-16', 'TUCH9900416XXX','1139', 3,'Gerente del Centro Muebles', 1),
('Israel', 'Valles', 'Escobedo', '2000-10-29', 'VAEI001029XXX','1037', 4, 'Encargado de Garant�as', 0),
('Rafael', 'Brito', 'Damian', '1985-08-11', 'BIDR850811XXX', '1037', 6, 'Cajero Ropa', 0),
('Luis', 'Mart�nez', 'Ram�rez', '1985-07-10', 'MARL850710XXX','1037', 5,'Gerente del Centro Ropa', 1),
('Armando', 'Zapata', 'Melo', '1990-07-02', 'ZAMA900702XXX','7883', 1,'Vendedor de piso', 0),
('Jesus', 'May', 'Perez', '1991-05-21', 'MAPJ9910521XXX','7883',8,'Intendente', 0),
('Felipe', 'Mendoza', 'Perez', '1990-10-03', 'MEPF901003XXX','7883', 7, 'Gerente de Tienda Motos', 1),
('Moises', 'Mateo', 'Hern�ndez', '1991-09-13', 'MAHM910913XXX','1051', 1, 'Vendedor de piso', 0),
('Amairani', 'Hernandez', 'Uc', '1995-03-18', 'HECA950318XXX','1051', 9, 'Encargada de Optica', 0),
('Ana', 'Torres', 'S�nchez', '1992-11-20', 'TOSA921120XXX','1051', 3,'Gerente del Centro Muebles', 1),
('Rubi', 'Sarmiento', 'Rodriguez', '1997-10-19', 'SARR971019XXX','877', 1,'Vendedor de Piso', 0),
('Cesar', 'Rodr�guez', 'C�mara', '1997-02-24', 'ROCC970224XXX','877', 10, 'Inventarista de la Zapater�a', 0),
('Jes�s', 'Vega', 'Castro', '1988-03-26', 'VECJ880326XXX','877', 11, 'Gerente de la Zapater�', 1),
('Omar', 'Silva', 'Lara', '2000-12-15', 'SILO001215XXX','1019', 1, 'Vendedor de Piso', 0),
('Heyder', 'Canto', 'Lopez', '1985-03-30', 'CALH850330XXX','1019', 13, 'T�cnico de Sector', 0),
('Mar�a', 'Garc�a', 'Hern�ndez', '1990-05-15', 'GAHM900515XXX','1019', 3, 'Gerente del Centro Muebles', 1);
GO
 --Directivo
INSERT INTO Directivo (Numero_Empleado, Centro_Responsable, Prestacion_Combustible) VALUES
(3,'1139', 1),
(6, '1037', 1),
(9, '7883', 1),
(12, '1051', 1),
(15, '877', 1),
(18, '1019', 1);
GO
